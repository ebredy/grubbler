<form class="form-inline navbar-form navbar-left" action="#" method="GET">
    <div class="form-group has-feedback">
        <input type="search" class="form-control search-bar" id="q" name="q" placeholder="Search by dish or restaurant">
        <span class="glyphicon glyphicon-search form-control-feedback" aria-hidden="true"></span>
    </div>
</form>