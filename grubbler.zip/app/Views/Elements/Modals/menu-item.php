<div class="modal fade" id="menu-item" tabindex="-1" role="dialog" aria-labelledby="menu-item-label" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
        </div>
    </div>
</div>