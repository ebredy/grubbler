<?php echo $__view->render('app/Views/Elements/navbar.php'); ?>
<div class="container">
    <div class="page-header">
        <h4>Your Restaurants</h4>
        <p class="text-muted"><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span> Showing restaurants near <b><?php echo $address; ?></b>. To change location <a href="/">click here</a></p>
    </div>
    <div class="row">
        <div class="col-md-4 well well-sm">
            <h4>Search Menus</h4>
            <form class="form-inline">
                <div class="form-group">
                    <label class="sr-only" for="exampleInputEmail3">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail3" placeholder="Enter email">
                </div>
                <button type="submit" class="btn btn-default">Search</button>
            </form>
            <h4>Cuisines</h4>
            <ul class="list-group">
                <li class="list-group-item">
                    <span class="badge">14</span>
                    Cras justo odio
                </li>
            </ul>
            <h4>Rating</h4>
            <ul class="list-group">
                <li class="list-group-item">
                    <span class="badge">14</span>
                    Cras justo odio
                </li>
            </ul>
            <h4>Minimum Delivery</h4>
            <ul class="list-group">
                <li class="list-group-item">
                    <span class="badge">14</span>
                    Cras justo odio
                </li>
            </ul>
        </div>
        <?php echo $__view->render('app/Views/Elements/restaurants.php'); ?>
    </div>
</div>
<?php echo $__view->render('app/Views/Elements/footer.php'); ?>