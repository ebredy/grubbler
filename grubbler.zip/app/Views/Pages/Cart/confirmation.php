<?php echo $__view->render('app/Views/Elements/navbar.php'); ?>
<div class="container">
    <div class="confirmation">
        <h1><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Your order has been placed!</h1>
        <p class="lead">What next? You will receive an email soon when the restaurant confirms your order!</p>
    </div>
</div>
<?php echo $__view->render('app/Views/Elements/footer.php'); ?>