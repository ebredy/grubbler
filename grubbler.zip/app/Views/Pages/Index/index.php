<?php echo $__view->render('app/Views/Elements/navbar.php'); ?>
    <div class="site-wrapper">
        <div class="container">
            <div class="header">
                <h2>The Ultimate Food Ordering Experience</h2>
                <p class="text-muted lead"><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span> 20 Beacon Way, NJ. <a href="#">Change Address</a>.</p>
            </div>
            <div class="row filters">
                <ul class="col-md-12 list-inline">
                    <li>
                        <a id="cuisineLabel" data-target="#" href="http://example.com" data-toggle="dropdown"
                           aria-haspopup="true" role="button"
                           aria-expanded="false">Cuisine <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu" role="menu" aria-labelledby="cuisineLabel">
                            <li><a href="#">Cost</a></li>
                            <li><a href="#">Delivery Fee</a></li>
                        </ul>
                    </li>
                    <li>
                        <a id="costLabel" data-target="#" href="http://example.com" data-toggle="dropdown"
                           aria-haspopup="true" role="button"
                           aria-expanded="false">Cost <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu" role="menu" aria-labelledby="costLabel">
                            <li><a href="#">Cost</a></li>
                            <li><a href="#">Delivery Fee</a></li>
                        </ul>
                    </li>
                    <li>
                        <a id="feeLabel" data-target="#" href="http://example.com" data-toggle="dropdown"
                           aria-haspopup="true" role="button"
                           aria-expanded="false">Cost <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu" role="menu" aria-labelledby="feeLabel">
                            <li><a href="#">Cost</a></li>
                            <li><a href="#">Delivery Fee</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="row">

                <?php if( !empty( $items[0] ) ) { ?>
                    <?php foreach( $items as $item ) { ?>
                        <div class="col-xs-6 col-md-3 food-item">
                            <div class="thumbnail">
                                <a href="/restaurants/<?php echo $item['restaurant_id']; ?>#<?php echo $item['id']; ?>" class="food-item-img" >
                                    <img src="<?php echo $item['image']; ?>" alt="...">
                                </a>
                                <div class="caption">
                                    <div class="row">
                                        <div class="col-md-9 food-item-title"><?php echo ucfirst( strtolower( $item['item'] ) ); ?></div>
                                        <?php if( !empty( $item['price'] ) ) { ?>
                                            <div class="col-md-3 text-right food-item-price"><?php echo '$' . ltrim( $item['price'], '$' ); ?></div>
                                        <?php } ?>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12 text-muted small">
                                            <span class="glyphicon glyphicon-cutlery" aria-hidden="true"></span> <a href="#">Royers Round Top Cafe, Brooklyn, NY</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="hidden-caption">
                                    <div class="row">
                                        <div class="col-md-12"><span class="glyphicon glyphicon-time" aria-hidden="true"></span> 35 mins est. &bull; $2 fee &bull; $20 minimum</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                <?php } else { ?>
                    <p class="small">No menu found</p>
                <?php } ?>

            </div><!-- /.row -->
        </div><!-- /.container -->
        <div class="overlay" style="display: none; opacity: 1;">
        </div>

<?php echo $__view->render('app/Views/Elements/footer.php'); ?>