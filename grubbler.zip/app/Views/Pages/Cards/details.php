<?php echo $__view->render('app/Views/Elements/navbar.php'); ?>
<div class="container">
    <div class="page-header">
        <h4>Card Details</h4>
    </div>
    <?php

    echo $last_4 . ' ' . $brand;
    ?>
</div>
<?php echo $__view->render('app/Views/Elements/footer.php'); ?>