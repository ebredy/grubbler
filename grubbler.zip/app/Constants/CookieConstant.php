<?php

namespace app\Constants;

class CookieConstant {

    const REMEMBER_ME  = 'remember_me';
    const MINI_CART    = 'cart_total';

}