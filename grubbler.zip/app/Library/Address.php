<?php

namespace app\Library;

use app\Constants\RouteConstant;

class Address extends Controller {

    public function getRecent( array $query = [] ) {

        $service_response   = $this->_getServiceResponse();
        $data               = [];
        $data['user_id']    = $this->_getUser( 'id' );
        $data['addresses']  = $this->addresses->getRecent( $data['user_id'], 12 );
        $data['action']     = ( !empty( $query['continue'] ) )
            ? $this->generateUrl( RouteConstant::ADDRESSES ) . '?continue='. $query['continue']
            : $this->generateUrl( RouteConstant::ADDRESSES );

        $service_response->setData( $data );

        return $service_response;

    }

    public function remove( $address_id ) {

        $service_response   = $this->_getServiceResponse();
        $address            = $this->addresses->read( [
            'id'        => $address_id,
            'user_id'   => $this->_getUser( 'id' )
        ] );

        if ( $address ) {

            $is_deleted = $this->addresses->delete( [ 'id' => $address_id ] );

            if ( !$is_deleted ) {
                $service_response->setError( 'flash', 'An error occurred. Please try again' );
            }

        } else {
            $service_response->setError( 'flash', 'Address not found' );
        }

        return $service_response;

    }

    public function getById( $address_id, array $query = [] ) {

        $service_response = $this->_getServiceResponse();
        $address          = $this->addresses->getById( $address_id );

        if ( !$address ) {
            return $service_response->setError( 'flash', 'The address you tried to edit is invalid or does no longer exist.' );
        }

        if ( !empty( $query['continue'] ) ) {
            $address['continue'] = $query['continue'];
        }

        return $service_response->setData( $address );

    }

    public function update( $address_id, array $params ) {

        $service_response = $this->_getServiceResponse();
        $address          = $this->addresses->getById( $address_id );

        if ( !$address ) {
            return $service_response->setError( 'flash', 'The address you tried to edit is invalid or does no longer exist.' );
        }

        foreach ( $address as $field => $value ) {

            if ( isset( $params[ $field ] ) && ( $params[ $field ] !== $value ) ) {
                $update[ $field ] = $params[ $field ];
            }

        }

        if ( empty( $update ) ) {
            return $service_response;
        }

        //TODO: Must have all states in database
        if ( !empty( $update['state'] ) ) {

            $state = $this->states->read( [ 'name' => $update['state'] ] );
            unset( $update['state'] );

            if ( $state ) {
                $update['state_id'] = $state['id'];
            }

        }

        //TODO: Validate city using google maps, in case of spelling errors!
        if ( !empty( $update['city'] ) ) {

            $city = $this->cities->read( [ 'name' => $update['city'] ] );

            if ( $city ) {
                $update['city_id'] = $city['id'];
            } else {
                $this->cities->save( [ 'name' => $update['city'] ] );
                $update['city_id'] = $this->cities->lastInsertId();
            }

            unset( $update['city'] );

        }

        $is_updated = ( !empty( $update ) )
            ? $this->addresses->update( [ 'id' => $address['id'] ], $update )
            : false;

        if ( !$is_updated ) {
            return $service_response->setError( 'flash', 'An error occurred while updating your address! Please try again.' );
        }

        return $service_response;

    }

    public function setCurrent( $address_id ) {

        $service_response = $this->_getServiceResponse();
        $user_id          = $this->_getUser( 'id' );
        $address          = $this->addresses->read( [
            'id'        => $address_id,
            'user_id'   => $user_id
        ] );

        if ( !$address ) {
            return $service_response->setError( 'flash', 'Invalid delivery address. Please try again' );
        }

        $update = [ 'last_used' => $this->_now() ];
        $is_set = $this->addresses->update( [ 'id' => $address_id ], $update );

        if ( !$is_set ) {
            return $service_response->setError( 'flash', 'An error occurred. Please try again' );
        }

        return $service_response;

    }

    public function create( array $params ) {

        $service_response   = $this->_getServiceResponse();
        $address_2          = !empty( $params['address_2'] ) ? $params['address_2'] : '';
        $address            = $params['address_1'] . ' ' . $address_2 . ' ' . ucfirst( $params['city'] ) . ' ' . $params['state']  . ' ' . $params['zip_code'];
        $suggestions        = $this->_verifyAddress( $address );

        if ( $suggestions ) {
            return $service_response->setError( 'suggestions', $suggestions );
        }

        $params['user_id'] = $this->_getUser( 'id' );
        $is_saved          = $this->_saveAddress( $params );

        if ( !$is_saved ) {
            return $service_response->setError( 'flash', 'An error occurred. Please try again' );
        }

        return $service_response;

    }





    //------

    private function _saveAddress( $params ) {

        $address = [];
        $state   = $this->states->read([
            'name' => $params['state']
        ]);

        if ( !$state ) {
            $this->states->save( [
                'name' => $params['state']
            ] );
            $address['state_id'] = $this->states->lastInsertId();
        } else {
            $address['state_id'] = $state['id'];
        }

        $city   = $this->cities->read([
            'name' => $params['city']
        ]);

        if ( !$city ) {
            $this->cities->save( [
                'name' => $params['city']
            ] );
            $address['city_id'] = $this->cities->lastInsertId();
        } else {
            $address['city_id'] = $city['id'];
        }

        $fields = [ 'address_1', 'address_2', 'phone', 'zip_code', 'fname', 'lname', 'user_id', 'apt_number', 'instructions' ];

        foreach ( $params as $field => $val ) {

            if ( in_array( $field, $fields ) && !empty( $val ) ) {
                $address[ $field ] = $val;
            }

        }

        return $this->addresses->save( $address );

    }

    private function _verifyAddress( $address ) {

        $addresses  = $this->map->getAddresses( $address );

        foreach ( $addresses as $verified ) {

            if ( strpos( $address, $verified['street']  ) === false ) {
                continue;
            }

            if ( strpos( $address, $verified['city'] ) === false ) {
                continue;
            }

            if ( strpos( $address, $verified['state'] ) === false ) {
                continue;
            }

            if ( strpos( $address, $verified['zip_code'] ) === false ) {
                continue;
            }

            return [];

        }

        return $addresses;

    }


}