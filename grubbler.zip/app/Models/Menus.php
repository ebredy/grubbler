<?php

namespace app\Models;

use Symfony\Component\Validator\Constraints as Assert;
use TinyPress\Abstracts\ModelAbstract;

class Menus extends ModelAbstract {

    const TABLE_NAME = 'menus';

    public function getTableName() {

        return self::TABLE_NAME;

    }

}