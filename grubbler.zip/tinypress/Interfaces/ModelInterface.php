<?php

namespace TinyPress\Interfaces;

Interface ModelInterface {

}
