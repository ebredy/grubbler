<?php

namespace TinyPress\Interfaces;

Interface ExceptionInterface {}
