<?php

namespace TinyPress\Exceptions;

use TinyPress\Interfaces\ExceptionInterface;

class HttpMethodNotAllowedException extends \RuntimeException implements ExceptionInterface {

}
