<?php

namespace TinyPress\Exceptions;

use TinyPress\Interfaces\ExceptionInterface;

class ServiceNotFoundException extends \Exception implements ExceptionInterface {

}