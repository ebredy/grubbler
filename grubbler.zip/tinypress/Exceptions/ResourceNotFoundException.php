<?php

namespace TinyPress\Exceptions;

use TinyPress\Interfaces\ExceptionInterface;

class ResourceNotFoundException extends \RuntimeException implements ExceptionInterface {

}
