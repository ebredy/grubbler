<?php

namespace TinyPress\Exceptions;

use TinyPress\Interfaces\ExceptionInterface;

class BadRequestHttpException extends \RuntimeException implements ExceptionInterface {

}
