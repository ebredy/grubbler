<?php

namespace TinyPress\Exceptions;

use TinyPress\Interfaces\ExceptionInterface;

class FileNotFoundException extends \RuntimeException implements ExceptionInterface {

}
