<?php

namespace TinyPress\Exceptions;

use TinyPress\Interfaces\ExceptionInterface;

class MissingRequiredParameterException extends \RuntimeException implements ExceptionInterface {

}
